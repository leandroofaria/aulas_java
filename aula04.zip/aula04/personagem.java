public class personagem {
    private String nome;
    private int vida;
    private int mana;

    public personagem(String nome, int vida, int mana) {
        this.nome = nome;
        this.vida = vida;
        this.mana = mana;
    };


    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    
    public void aplicarDano(int dano) {
        vida -= dano;
        if(vida < 0) {
            vida=0;
            System.out.println(nome + "está morto(a).");
            return;
            // Se a vida chegar a 0, nada abaixo dessa linha será executado.
        }

        System.out.println("O dano recebido é de: " + dano );
        System.out.println("Você tem " + vida + " pontos de vida.");
    }

    public void usarFeitiço(String nome, int mana) {
        this.mana -= mana;
        if(mana<0) {
            this.mana = 0;
            System.out.println("Você está sem mana...");
            return;
        } 
        System.out.println("Você usou o feitiço " + nome);
        System.out.println("Você tem " + this.mana + " pontos de mana restantes.");
    }

    public void mostrarMana() {
        System.out.println("Mana atual: " + this.mana);
    }
}
